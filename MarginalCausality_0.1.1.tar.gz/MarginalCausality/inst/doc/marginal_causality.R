## ----echo=FALSE,message=FALSE--------------------------------------------
require(knitr)
require(mvtnorm)
require(igraph)
require(Rgraphviz)
require(MarginalCausality)
ornon<-function(W,m=rep(0,ncol(W)),sigma2=rep(0.1,ncol(W))) # Obtention of the non oriented model parameters from the oriented model.
{
  d=length(m)
  if (abs(det(diag(d)-W))<10^(-8))
    {
      stop("Model not correctly specified")
    }
  L=solve(diag(d)-W)
  mu=matrix(m,1,d)%*%L
  Sigma=crossprod(L,diag(sigma2))%*%L
  return(list(mu=mu,Sigma=Sigma))
}

## ------------------------------------------------------------------------
## Data clearly generated under a particular SEM: here, alpha=2, mu_G=-2 and mu_X=1
wt <- rnorm(n=20,mean=-2,sd=0.02)
wt <- cbind(wt,2*wt+rnorm(n=20,mean=1,sd=0.07))

## ------------------------------------------------------------------------
## Interventional data
ko <- rnorm(n=20,mean=0,sd=10e-5)
ko <- cbind(ko,2*ko+rnorm(n=20,mean=1,sd=0.07))

## ----echo=FALSE,message=FALSE,fig.width=8,fig.height=6-------------------
W=matrix(0,13,13) # On regarde 1,2,4,5,7,8,11,12,13
W[1:2,3]=c(0.1,-1.55)
W[2,4]=0.4
W[c(3,5),6]=c(1.5,-0.9)
W[2,7]=-1.1
W[5,8]=-2.2
W[6,9]=3
W[6:7,10]=c(-1.3,-0.2)
W[9,11]=-0.005
W[c(9,11),12]=c(1,0.1)
W[10,13]=1
colnames(W)=rownames(W)=1:13
L=solve(diag(13)-W)
k=1
s=k*exp(rnorm(13,0,0.5))
s[c(1,8,13)]=s[c(1,8,13)]*100
me=rnorm(13,0,2)
names(s)=names(me)=LETTERS[1:13]
par=list(mean=me,sigma2=s,W=W)
parobs=ornon(W = par$W,m = par$mean,sigma2 = par$sigma2)
Wtilde=W; Wtilde[,6]=0;
mtilde=par$mean; mtilde[6]=0;
sigma2tilde=par$sigma2; sigma2tilde[6]=0.01;
parko=ornon(W = Wtilde,m = mtilde,sigma2 = sigma2tilde)
set.seed(42)
N=48
g=graph.adjacency(W,weighted = TRUE)
gNEL=igraph.to.graphNEL(g)
eAttrs=c()
nAttrs=c()
nodcol=c(rep("blue",4),rep("green",3),rep("red",5),"yellow") ; 
names(nodcol)=nodes(gNEL)[c(1,2,3,5,4,7,8,9,10,11,12,13,6)] ;
nAttrs$fillcolor=nodcol
ew=as.character(unlist(edgeWeights(gNEL)))
ew=ew[setdiff(seq(along=ew),removedEdges(gNEL))]
names(ew)=edgeNames(gNEL)
eAttrs$label=ew
ewcol=ew; ewcol[1:14]="red"
eAttrs$fontcolor=ewcol
plot(gNEL,nodeAttrs=nAttrs,edgeAttrs=eAttrs,attrs=list(edge=list(fontsize=8)))
legend(x="bottomright",legend = c("Intervention","Upstream","Correlation","Downstream"),pch = 10, col=c("yellow","blue","green","red"))

## ----fig.width=8,fig.height=6--------------------------------------------
nrep=100
rdown=matrix(NA,nrep,13)
rcor=matrix(NA,nrep,13)
par=c(alpha=3,muG=11.42,muX=32,sigmaG=log(10),sigmaX=log(95))
for (rep in 1:nrep){
  # simulation
  xobs=rmvnorm(n = N/2,mean = parobs$mu,sigma = parobs$Sigma)
  xko=rmvnorm(n = N/2,mean = parko$mu,sigma = parko$Sigma)
  # loop on all tested genes
  for (j in c(1:13)[-6]){
    wt=xobs[,c(6,j)]
    ko=xko[,c(6,j)]
    rdown[rep,j]=loglik.down(wt=wt,ko=ko,par=par)
    rcor[rep,j]=loglik.cor(wt=wt,ko=ko,par=par)
  }
}

type=matrix(rep(1:13,nrep),nrep,13,byrow=TRUE)
boxplot(c(-rdown)~c(type),xlab="gene index",ylab="loglog-lik",col="red",ylim=c(min(-rcor,na.rm=TRUE)-5,max(-rdown,na.rm=TRUE)+5))
boxplot(c(-rcor)~c(type),xlab="gene index",ylab="loglog-lik",col="blue",add=TRUE)

## ----fig.width=8,fig.height=6--------------------------------------------
nrep=100
res=matrix(NA,nrep,13)
for (rep in 1:nrep){
  # simulation
  xobs=rmvnorm(n = N/2,mean = parobs$mu,sigma = parobs$Sigma)
  xko=rmvnorm(n = N/2,mean = parko$mu,sigma = parko$Sigma)
  # loop on all tested genes
  for (j in c(1:13)[-6]){
    wt=xobs[,c(6,j)]
    ko=xko[,c(6,j)]
    res[rep,j]=post.causal(wt = wt,ko= ko)$B
  }
}
type=matrix(rep(1:13,nrep),nrep,13,byrow=TRUE)
boxplot(c(log10(res))~c(type),xlab="gene index",ylab="log10(Bayes factor)",col=c(rep(1,7),rep(2,5)))
abline(v=7.5,lty=2,col="blue",lwd=2)
title("Boxplot of Bayes factor for all genes.")

## ------------------------------------------------------------------------
N=48
nrep=25
coeff=vector(mode="list",length=nrep)
for (rep in 1:nrep){
  # simulation
  xobs=rmvnorm(n = N/2,mean = parobs$mu,sigma = parobs$Sigma)
  xko=rmvnorm(n = N/2,mean = parko$mu,sigma = parko$Sigma)
  # loop on all tested genes
  coeff[[rep]]=vector(mode="list",length=13)
  for (j in c(1:13)[-6]){
    wt=xobs[,c(6,j)]
    ko=xko[,c(6,j)]
    if (j>8) {
      coeff[[rep]][[j]]=post.causal(wt = wt,ko= ko)$down$par[1]
    } else if(match(j,c(4,7,8),nomatch = 0)>0) {
      coeff[[rep]][[j]]=undownstream(post.causal(wt = wt,ko= ko)$cor$par,to="cor")[1]
    } else {
      coeff[[rep]][[j]]=undownstream(post.causal(wt = wt,ko= ko)$cor$par,to="up")[1]
    }
  }
}
Effects <- matrix(unlist(coeff),nrow=nrep,ncol=12,byrow=TRUE)
trueCoeff=rep(NA,12)
trueCoeff[4]=parobs$Sigma[4,6]/sqrt(parobs$Sigma[4,4]*parobs$Sigma[6,6])
trueCoeff[6]=parobs$Sigma[7,6]/sqrt(parobs$Sigma[7,7]*parobs$Sigma[6,6])
trueCoeff[7]=parobs$Sigma[8,6]/sqrt(parobs$Sigma[8,8]*parobs$Sigma[6,6])
trueCoeff[c(1,2,3,5)]=L[c(1,2,3,5),6]
trueCoeff[c(8:12)]=L[6,9:13]
k_Effects <- rbind(trueCoeff,apply(Effects,2,mean),apply(Effects,2,sd))
rownames(k_Effects)=c("True Coefficient","Computed mean","Computed standard deviation")
kable(k_Effects,digits=3,col.names = paste("Node ",c(1:13)[-6],sep=""),caption="Several kinds of coefficients depending on the node: correlation coefficient for the nodes 4, 7 and 8, total upstream causal effect on 6 for nodes 1, 2, 3, 5 and total downstream causal effect of 6 for the other ones.")

